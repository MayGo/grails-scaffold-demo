package org.grails.samples.pages

import geb.Page

class ShowOwnerPage extends Page {
	
	static at = {
		title == 'Owner Information'
	}

}
