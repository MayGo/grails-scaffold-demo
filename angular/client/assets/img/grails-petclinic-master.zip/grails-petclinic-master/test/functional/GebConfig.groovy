import org.openqa.selenium.htmlunit.HtmlUnitDriver

driver = {
	new HtmlUnitDriver()
}
