Grails Pomodoro Application
===========================

This is the sample [Pomodoro][1] application as used for the 'Getting started with Grails' [series of screencasts][2]. Each screencast has its own tag within the repository so that you can easily see the code at any particular stage.

[1]: http://www.pomodorotechnique.com/
[2]: http://grails.org/screencast/search?tag=gswg
