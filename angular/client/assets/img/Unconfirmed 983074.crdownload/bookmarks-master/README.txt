Bookmarks Sample Application
----------------------------

This is the sample application from the book "The Defintive Guide to Grails" by
Graeme Rocher (see http://www.apress.com/book/bookDisplay.html?bID=10205)

It shows integration with Java frameworks and services like Xfire, Acegi and Hibernate.
It also includes del.icio.us integration.

To get started type 

grails run-app

And navigate to:

http://localhost:8080/bookmarks

Register with the same user details that you registered with del.icio.us for (if you have an account).
Then login and start adding bookmarks, and searching del.icio.us.

Enjoy!