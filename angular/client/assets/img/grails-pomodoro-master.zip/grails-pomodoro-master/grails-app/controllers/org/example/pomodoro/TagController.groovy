package org.example.pomodoro

class TagController {
    static scaffold = Tag
}
